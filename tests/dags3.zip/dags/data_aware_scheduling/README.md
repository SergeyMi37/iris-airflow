The Data-aware scheduling feature is available in version 2.4.0 or later.
Please see [here](https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/datasets.html).

#### example_producer_consumer

![data_aware_scheduling](https://user-images.githubusercontent.com/43136241/226323515-75acbc97-9039-46bf-b1c6-cca78ac3cda2.png)
