## Dynamic Task Mapping

The Dynamic Task Mapping feature is available in version 2.3.0 or later.
Please see [here](https://airflow.apache.org/docs/apache-airflow/2.3.0/concepts/dynamic-task-mapping.html)

#### `example_dtm_non_taskflow`

[![](https://user-images.githubusercontent.com/43136241/167180469-7573bdc6-014a-45ce-8d99-9550d1b6722a.png)](https://user-images.githubusercontent.com/43136241/167180469-7573bdc6-014a-45ce-8d99-9550d1b6722a.png)