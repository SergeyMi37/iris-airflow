## Build tasks

A method for developing Airflow DAG by dividing it into sub-workflow level.

Please see [here](https://speakerdeck.com/matsudan/tech-x-marketing-number-4-airflowdemosabuwakuhurodan-wei-defen-ge-kai-fa-sitai)