## SLAs

### Requirements

- [slack Variable](../../config/slack.json) needs to be set to send notifications to your slack channel.
